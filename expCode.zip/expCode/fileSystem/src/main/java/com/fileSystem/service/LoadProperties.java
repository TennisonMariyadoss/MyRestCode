package com.fileSystem.service;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import com.fileSystem.common.Constants;

public class LoadProperties {
	
	private static Properties expception; 
	private static Properties fileSystem; 
	
	private static LoadProperties properties;
	
	public static LoadProperties getLoadProperties() {
		if(properties == null) {
			properties = new LoadProperties();
		}
		return properties;
	}
	
	private LoadProperties() {
		
	}

	
	public void setLoadProperties(String fileType) throws IOException {
		
		if(fileType.equalsIgnoreCase(Constants.EXP_TYPE)) {
			FileReader expReader=new FileReader(Constants.EXP_PRO);  
			expception =new Properties();
			expception.load(expReader);  
		}else {
			FileReader fileReader=new FileReader(Constants.FILE_PRO); 
			fileSystem = new Properties();
			fileSystem.load(fileReader);
		}		
		
	}
	
	public String getExpectionMsg(String code) {
		return expception.getProperty(code);
	}
	
	public String getFileProperties(String code) {
		return fileSystem.getProperty(code);
	}
	
	
	
	

}
