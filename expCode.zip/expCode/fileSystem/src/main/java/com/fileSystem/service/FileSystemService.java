package com.fileSystem.service;

import com.fileSystem.common.DataSheet;

public interface FileSystemService {
	
	public String create(String key, DataSheet value) throws FileException;
	
	public String delete(String key) throws FileException;
	
	public DataSheet read(String key) throws FileException;

}
