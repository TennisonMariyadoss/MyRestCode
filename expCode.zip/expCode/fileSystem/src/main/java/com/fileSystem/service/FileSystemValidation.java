package com.fileSystem.service;

import java.math.BigDecimal;
import java.util.Date;

import org.json.simple.JSONObject;


public class FileSystemValidation {
	
	private static FileSystemValidation validation;
	
	private FileSystemValidation() {
		
	}
	
	public static FileSystemValidation getFileSystemValidationInstance() {
		
		if(validation == null) {
			validation = new FileSystemValidation();
		}
		
		return validation;
		
	}
	
	
	public Boolean validateInputData(String key, String value) {
		if(key.length() <= 32 && (value.toString().length() / 1024 ) <= 16) {
			return Boolean.TRUE;
		}
		
		return Boolean.FALSE;	}
	
	public Boolean checkKeyPersent(JSONObject dataSheet, String key) {
		if(dataSheet.containsKey(key)) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	public Boolean checkSpace(Long fileLength) {
		
		//Add max size of one insert
		fileLength += 16 * 1024;
		
		BigDecimal fileinKB = new BigDecimal(fileLength / (1024*1024*1024));
		if(fileinKB.doubleValue() > 1) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}
	
	
	public Boolean validateRead(Long value, Long timeToLive) {
				
		if((value + timeToLive) >= new Date().getTime()){
			return Boolean.TRUE;
		}
		
		return Boolean.FALSE;
		
	}

}

