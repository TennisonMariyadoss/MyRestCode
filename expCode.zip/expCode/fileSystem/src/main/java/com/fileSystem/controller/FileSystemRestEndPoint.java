package com.fileSystem.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import com.fileSystem.common.DataSheet;
import com.fileSystem.service.FileException;
import com.fileSystem.service.FileSystemService;
import com.fileSystem.service.FileSystemServiceImpl;

@Path("/fileSystem")
public class FileSystemRestEndPoint {
	
	private FileSystemService service;
	
	private String loadProperties;
	
	public FileSystemRestEndPoint()  {
		try {
			service = new FileSystemServiceImpl();
		} catch (FileException e) {
			loadProperties = e.getMessage();
			e.printStackTrace();
		}
	}

	@POST
	@Path("create/{key}")
    @Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
    public Response create(@PathParam("key") String key, String  value) {
		
		if(loadProperties == null || loadProperties.isEmpty() ) {
			String resp;
			try {
				resp = service.create(key, new DataSheet(value));
			} catch (FileException e) {
				resp=e.getMessage();
				e.printStackTrace();
			}
	        return Response.status(200).entity(resp).build();
		}
        return Response.status(200).entity(loadProperties).build();
  
    }
	
	@GET
	@Path("delete/{key}")
	@Produces(MediaType.TEXT_PLAIN)
    public Response delete(@PathParam("key") String key) {
		
		if(loadProperties == null || loadProperties.isEmpty() ) {
			String resp;
			try {
				resp = service.delete(key);
			} catch (FileException e) {
				resp=e.getMessage();
				e.printStackTrace();
			}
	        return Response.status(200).entity(resp).build();
		}
        return Response.status(200).entity(loadProperties).build();
  
    }
	
	@GET
	@Path("read/{key}")
	@Produces(MediaType.APPLICATION_JSON)
    public Response read(@PathParam("key") String key) {
		
		if(loadProperties == null || loadProperties.isEmpty() ) {
			String resp;
			try {
				DataSheet dataValue  = service.read(key);
				resp = dataValue.getValue().toJSONString();
			} catch (FileException e) {
				resp=e.getMessage();
				e.printStackTrace();
			}
	        return Response.status(200).entity(resp).build();
		}
        return Response.status(200).entity(loadProperties).build();
  
    }
  
}
