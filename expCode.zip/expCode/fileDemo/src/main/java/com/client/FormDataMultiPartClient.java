package com.client;

import java.io.File;
import java.io.IOException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;

public class FormDataMultiPartClient {
	
	public static void main(String[] args) throws IOException 
	{
	    Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();
	 
	    FileDataBodyPart filePart = new FileDataBodyPart("file", new File("C:\\Users\\TE325757\\Downloads\\NI00904414.pdf"));
	    FormDataMultiPart formDataMultiPart = new FormDataMultiPart();
	    FormDataMultiPart multipart = (FormDataMultiPart) formDataMultiPart.bodyPart(filePart);
	      
	    WebTarget target = client.target("http://localhost:8080/rest/upload/pdf");
	    Response response = target.request().post(Entity.entity(multipart, multipart.getMediaType()));
	    
	    if(response.getStatus() != 200) {
	    	System.err.println("error code"+response.getStatus());
	    }else {
	    	System.out.println("uploaded successfully...");
	    }
	     
	    //Use response object to verify upload success
	     
	    formDataMultiPart.close();
	    multipart.close();
	}

}
