package com.howtodoinjava.jersey;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

@Path("/download")
public class JerseyService 
{
	@GET
	@Path("/pdf")
	public Response downloadPdfFile() throws MissingFileException	{
		
		String fullFilePath = "C:\\Users\\TE325757\\Downloads\\NI00904414.pdf";
        
        File file = new File(fullFilePath);
         
        if(file.exists() == false){
            throw new MissingFileException("file does not existing on this server !!");
        }
        
		StreamingOutput fileStream =  new StreamingOutput() 
		{
			public void write(java.io.OutputStream output) throws IOException, WebApplicationException 
			{
				try 
				{
					File file = new File("C:\\Users\\TE325757\\Downloads\\NI00904414.pdf");
					byte[] data = Files.readAllBytes(file.toPath());
					output.write(data);
					output.flush();
				} 
				catch (Exception e) 
				{
					throw new WebApplicationException("File Not Found !!");
				}
			}
		};
		return Response
	            .ok(fileStream, MediaType.APPLICATION_OCTET_STREAM)
	            .header("content-disposition","attachment; filename = myfile.pdf")
	            .build();
	}
}
