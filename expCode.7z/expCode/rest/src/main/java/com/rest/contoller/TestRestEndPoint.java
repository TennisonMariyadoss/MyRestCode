package com.rest.contoller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.rest.been.Employee;

@Path("/restCheck")
public class TestRestEndPoint {
	
	
	@Path("/getMsg/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public Response getMsg() {
		
		//System.out.println(name);
		
		Employee emp = new Employee();
		emp.setAddress("chennai");;
		emp.setId("202");
		emp.setName("Raj");
        return Response.status(200).entity(emp).build();
	}
	
	@POST
	@Path("/getJsonMsg")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_XML)
	public Response getJson(Employee employee) {
		
		System.out.println(employee);
		
		employee.setAddress("Chennai");
		
        return Response.status(200).entity(employee).build();
	}
	

}
