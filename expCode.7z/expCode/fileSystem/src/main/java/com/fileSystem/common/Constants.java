package com.fileSystem.common;

public class Constants {
	
	public static final String EXP_PRO = "src\\main\\resources\\exceptionMsg.properties";
	
	public static final String FILE_PRO = "src\\main\\resources\\fileSystem.properties";
	
	public static final String EXP_TYPE ="Exception";
	
	public static final String FILE_SYS = "File System";
	 

}
