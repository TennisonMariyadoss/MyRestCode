package com.fileSystem.service;

import com.fileSystem.common.Constants;

public class FileException extends Exception {

	private static final long serialVersionUID = 1L;

	private LoadProperties properties = LoadProperties.getLoadProperties();

	private String errorMsg;



	@Override
	public String getMessage() {
		super.getMessage();
		return errorMsg;
	}

	public FileException(String errorCode) {
		try {
			properties.setLoadProperties(Constants.EXP_TYPE);
		} catch (Exception e) {
			System.out.println("Proper file can't able to load " + e.getMessage());
			e.printStackTrace();
		}
		errorMsg = properties.getExpectionMsg(errorCode);
		if (errorMsg == null) {
			errorMsg = "Unexpected error occur.. Please try again.";
		}
	}

}
