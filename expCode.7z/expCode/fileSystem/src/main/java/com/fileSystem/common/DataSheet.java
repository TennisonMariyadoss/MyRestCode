package com.fileSystem.common;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fileSystem.service.FileException;

public class DataSheet  {
	
	private JSONObject value;
	
	private Long time;
	
	
	

	public DataSheet(String value) throws FileException {
		super();
		JSONParser parser = new JSONParser();
		try {
			this.value = (JSONObject) parser.parse(value);
		} catch (ParseException e) {
			throw new FileException("109");
		}
	}

	public JSONObject getValue() {
		return value;
	}

	public void setValue(JSONObject value) {
		this.value = value;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}
	
	

}
