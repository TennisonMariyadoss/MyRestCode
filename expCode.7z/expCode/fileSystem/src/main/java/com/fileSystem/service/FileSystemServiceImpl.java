package com.fileSystem.service;


import com.fileSystem.common.DataSheet;
import com.fileSystem.dao.FileSysteDaoImpl;
import com.fileSystem.dao.FileSystemDao;

public class FileSystemServiceImpl implements FileSystemService {
	
	
	private FileSystemValidation validate;

	
	private FileSystemDao dao;
	
	public FileSystemServiceImpl() throws FileException {
		validate= FileSystemValidation.getFileSystemValidationInstance();
		dao = new FileSysteDaoImpl();
	}

	public String create(String key, DataSheet value) throws FileException {
		
		//validate given input
		if(validate.validateInputData(key,value.getValue().toJSONString())) {
			return dao.create(key, value);
		}else {
			throw new FileException("108");
		}
	}

	public String delete(String key) throws FileException {
		return dao.delete(key);
	}

	public DataSheet read(String key) throws FileException {
		return dao.read(key);
	}

}
