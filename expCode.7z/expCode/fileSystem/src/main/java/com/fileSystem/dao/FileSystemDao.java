package com.fileSystem.dao;


import com.fileSystem.common.DataSheet;
import com.fileSystem.service.FileException;

public interface FileSystemDao {
	
public String create(String key, DataSheet value) throws FileException;
	
	public String delete(String key) throws FileException;
	
	public DataSheet read(String key) throws FileException;

}
