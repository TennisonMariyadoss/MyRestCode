package restTest.restClient;

import javax.ws.rs.core.MediaType;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;


public class RESTfulClient {
	
	public static void main(String[] arg ) throws JsonProcessingException {
		String serviceURL="http://localhost:7070/restWork/restCheck/getJsonMsg";
		//String serviceURL = "http://localhost:7070/restWork/restCheck/getMsg/raj";
		
		
		
		ClientConfig config = new DefaultClientConfig();
		Client restClient = Client.create(config);
		//restClient.setConnectTimeout(1000);
		WebResource webResource = restClient.resource(serviceURL);
		//ClientResponse response = webResource.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
		
		Employee emp = new Employee();
		emp.setAddress("Thanajavur");;
		emp.setId("202");
		emp.setName("Raj");
		
		ObjectMapper Obj = new ObjectMapper();   
	    String jsonStr = Obj.writeValueAsString(emp); 
		ClientResponse response = webResource.accept(MediaType.APPLICATION_XML).type(MediaType.APPLICATION_JSON).post(ClientResponse.class,jsonStr);

		if (response.getStatus() != 200) {
		   throw new RuntimeException("Failed : HTTP error code : "
			+ response.getStatus());
		}

		String output = response.getEntity(String.class);

		System.out.println("Output from Server .... \n");
		System.out.println(output);
	}

}
